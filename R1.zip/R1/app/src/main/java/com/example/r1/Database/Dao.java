package com.example.r1.Database;


import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@androidx.room.Dao
public interface Dao {

    @Insert
    public void insertStuVal(Student stu);

    @Query(value = "select * from Student where firstName like :firstName")
    Student searchByfname(String firstName);

    @Query(value = "select * from Student")
    public List<Student> getAllStudents();

    @Query("UPDATE Student SET firstName = :firstname,lastName = :lastName WHERE uid = :uid")
    void setUpdate(String firstname ,String lastName ,int uid);

    @Update
    public void updateStuVal(Student stu);

}
