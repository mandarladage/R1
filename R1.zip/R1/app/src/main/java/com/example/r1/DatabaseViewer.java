package com.example.r1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.content.Context;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.Toast;

import com.example.r1.Database.MyDatabase;
import com.example.r1.Database.Student;

import java.util.List;

public class DatabaseViewer extends AppCompatActivity {

    RecyclerView rec_view;
    StudentAdapter studentAdapter;
    private MyDatabase db;
    List<Student> studentList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database_viewer);
        setupDb();

        rec_view = findViewById(R.id.rec_view);

        studentList = db.dao().getAllStudents();

        rec_view.setLayoutManager(new LinearLayoutManager(DatabaseViewer.this));


        if (studentList.isEmpty()){
            Toast.makeText(DatabaseViewer.this,"No recent Items are Present",Toast.LENGTH_LONG).show();
        }else {
            studentAdapter = new StudentAdapter(DatabaseViewer.this,studentList);
            rec_view.setAdapter(studentAdapter);
        }

    }

    public Context gcontext(){
        return getApplicationContext();
    }

    private void setupDb() {
        db = Room.databaseBuilder(DatabaseViewer.this, MyDatabase.class,"trialStudentDb")
                .allowMainThreadQueries()
                .build();
    }
}