package com.example.r1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.r1.Database.MyDatabase;
import com.example.r1.Database.Student;

public class InsertData extends AppCompatActivity {

    EditText fName,lName;
    Button register;
    private MyDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_data);

        setupDb();

        fName = findViewById(R.id.textFirstName);
        lName = findViewById(R.id.textLastName);
        register = findViewById(R.id.register);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Student student = new Student(fName.getText().toString(),lName.getText().toString());

                db.dao().insertStuVal(student);

                Toast.makeText(InsertData.this,"Insertion Completed!!!",Toast.LENGTH_LONG).show();

                Intent intent = new Intent(InsertData.this,MainActivity.class);
                startActivity(intent);
                finishAffinity();

            }
        });

    }

    private void setupDb() {
        db = Room.databaseBuilder(InsertData.this,MyDatabase.class,"trialStudentDb")
                .allowMainThreadQueries()
                .build();
    }
}