package com.example.r1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.r1.Database.MyDatabase;
import com.example.r1.Database.Student;

import java.util.List;

public class SearchAndShow extends AppCompatActivity {

    EditText search;
    Button getDataButton;
    TextView fname,lname;
    private MyDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_and_show);

        db = Room.databaseBuilder(SearchAndShow.this,MyDatabase.class,"trialStudentDb")
                .allowMainThreadQueries()
                .build();

        search = findViewById(R.id.search);
        getDataButton = findViewById(R.id.getDataBtn);
        fname = findViewById(R.id.getFirstName);
        lname = findViewById(R.id.getLastName);

        getDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String searchME = getDataButton.getText().toString();
                Student stu = db.dao().searchByfname(search.getText().toString());
                if(stu == null){
                    Toast.makeText(SearchAndShow.this,"Sorry not found!!!",Toast.LENGTH_LONG).show();
                }else {
                    fname.setText(stu.firstName);
                    lname.setText(stu.lastName);
                }

            }
        });
    }
}