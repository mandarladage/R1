package com.example.r1.Update;

public class GetMeList {
}
