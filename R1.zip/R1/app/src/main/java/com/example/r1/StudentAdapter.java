package com.example.r1;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.r1.Database.Student;
import com.example.r1.Update.GetMeUpdateList;

import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.myViewHolder> {

    Context context;
    List<Student> stuList;
    View view;

    public StudentAdapter(Context context, List<Student> stuList) {
        this.context = context;
        this.stuList = stuList;
    }

    @Override
    public myViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        view = LayoutInflater.from(context).inflate(R.layout.rv_layout,parent,false);
        return new myViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StudentAdapter.myViewHolder holder, int position) {

        Student student =stuList.get(position);
        if (student == null){
            Toast.makeText(context,"Empty",Toast.LENGTH_LONG).show();
        }else {
            holder.stuID_v.setText(Integer.toString(student.getUid()));
            holder.fName_v.setText(student.getFirstName());
            holder.lName_v.setText(student.getLastName());
        }

        holder.tbr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context,GetMeUpdateList.class);
                intent.putExtra("myID",student.getUid());
                intent.putExtra("fname",student.getFirstName());
                intent.putExtra("lname",student.getLastName());
                holder.itemView.getContext().startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return stuList.size();
    }

    public static class myViewHolder extends RecyclerView.ViewHolder{
        TextView stuID_v,fName_v,lName_v;
        TableRow tbr;
        public myViewHolder(View itemView) {
            super(itemView);
            stuID_v = itemView.findViewById(R.id.stuId_v);
            fName_v = itemView.findViewById(R.id.fName_v);
            lName_v = itemView.findViewById(R.id.lName_v);
            tbr = itemView.findViewById(R.id.tablerow);



        }
    }


}
