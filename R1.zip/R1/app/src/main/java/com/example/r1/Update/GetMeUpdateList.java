package com.example.r1.Update;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.r1.Database.MyDatabase;
import com.example.r1.Database.Student;
import com.example.r1.DatabaseViewer;
import com.example.r1.R;

public class GetMeUpdateList extends AppCompatActivity {

    EditText upfName,uplName;
    Button upDataBtn;
    private MyDatabase db;
    int myID;
    String fname,lname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_me_update_list);

        setupDb();

        upfName = findViewById(R.id.upFirstName);
        uplName = findViewById(R.id.upLastName);
        upDataBtn = findViewById(R.id.updateDataBtn);

       myID = getIntent().getIntExtra("myID",0);
       fname = getIntent().getStringExtra("fname");
       lname = getIntent().getStringExtra("lname");


       upfName.setText(fname);
       uplName.setText(lname);

       upDataBtn.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

//                Student student = new Student(fname,lname);
//                student.setUid(myID);
                db.dao().setUpdate(fname,lname,myID);
//                Intent intent = new Intent(GetMeUpdateList.this,DatabaseViewer.class);
//                startActivity(intent);
//                finishAffinity();
               Toast.makeText(GetMeUpdateList.this,"Done",Toast.LENGTH_LONG).show();
           }
       });


    }

    private void setupDb() {
        db = Room.databaseBuilder(GetMeUpdateList.this, MyDatabase.class,"trialStudentDb")
                .allowMainThreadQueries()
                .build();
    }
}